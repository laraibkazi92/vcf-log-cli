from .start import app
app(prog_name='kazi-log')