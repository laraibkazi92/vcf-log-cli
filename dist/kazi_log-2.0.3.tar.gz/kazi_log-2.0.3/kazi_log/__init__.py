
__version__ = "2.0.3"
__serviceLogs__ = ['lcm', 'domainmanager', 'commonsvcs', 'operationsmanager', 'sddc-manager-ui-app']
